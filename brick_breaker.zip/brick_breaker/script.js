const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let nickname = "";
let score = 0, lives = 3;
let ballSpeed = 2;
let gameRunning = false;
let showMessageTimeout;

const paddle = {
  x: canvas.width / 2 - 35,
  width: 70,
  height: 10,
  speed: 5,
  dx: 0
};

const ball = {
  x: canvas.width / 2,
  y: canvas.height - 30,
  dx: ballSpeed,
  dy: -ballSpeed,
  radius: 5
};

const brickRowCount = 6;   // Aumentado de 3 para 6
const brickColumnCount = 7;   // Aumentado de 5 para 7
const bricks = [];
const brickWidth = 55, brickHeight = 20, padding = 10, offsetTop = 30, offsetLeft = 20;

function createBricks() {
  for (let c = 0; c < brickColumnCount; c++) {
    bricks[c] = [];
    for (let r = 0; r < brickRowCount; r++) {
      bricks[c][r] = { x: 0, y: 0, status: 1 };
    }
  }
}

createBricks();

document.addEventListener("keydown", (e) => {
  if (e.key === "a") paddle.dx = -paddle.speed;
  else if (e.key === "d") paddle.dx = paddle.speed;
});

document.addEventListener("keyup", (e) => {
  if (e.key === "a" || e.key === "d") paddle.dx = 0;  
});

function drawBall() {
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = "#fff";
  ctx.fill();
  ctx.closePath();
}

function drawPaddle() {
  ctx.beginPath();
  ctx.rect(paddle.x, canvas.height - paddle.height, paddle.width, paddle.height);
  ctx.fillStyle = "#0f0";
  ctx.fill();
  ctx.closePath();
}

function drawBricks() {
  let allDestroyed = true;

  for (let c = 0; c < brickColumnCount; c++) {
    for (let r = 0; r < brickRowCount; r++) {
      const b = bricks[c][r];
      if (b.status === 1) {
        allDestroyed = false;
        const brickX = (c * (brickWidth + padding)) + offsetLeft;
        const brickY = (r * (brickHeight + padding)) + offsetTop;
        b.x = brickX;
        b.y = brickY;
        ctx.beginPath();
        ctx.rect(brickX, brickY, brickWidth, brickHeight);
        ctx.fillStyle = "#f00";
        ctx.fill();
        ctx.closePath();
      }
    }
  }

  if (allDestroyed) {
    endGame(true);
  }
}

function collisionDetection() {
  for (let c = 0; c < brickColumnCount; c++) {
    for (let r = 0; r < brickRowCount; r++) {
      const b = bricks[c][r];
      if (b.status == 1) {
        if (
          ball.x > b.x && ball.x < b.x + brickWidth &&
          ball.y > b.y && ball.y < b.y + brickHeight
        ) {
          ball.dy = -ball.dy;
          b.status = 0;
          score += 5;
          document.getElementById("score").innerText = score;
          ball.dx *= 1.05;
          ball.dy *= 1.05;
        }
      }
    }
  }
}

function draw() {
  if (!gameRunning) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBricks();
  drawBall();
  drawPaddle();
  collisionDetection();

  paddle.x += paddle.dx;
  if (paddle.x < 0) paddle.x = 0;
  if (paddle.x + paddle.width > canvas.width) paddle.x = canvas.width - paddle.width;

  if (ball.x + ball.dx > canvas.width - ball.radius || ball.x + ball.dx < ball.radius)
    ball.dx = -ball.dx;

  if (ball.y + ball.dy < ball.radius)
    ball.dy = -ball.dy;
  else if (ball.y + ball.dy > canvas.height - ball.radius) {
    if (ball.x > paddle.x && ball.x < paddle.x + paddle.width)
      ball.dy = -ball.dy;
    else {
      lives--;
      document.getElementById("lives").innerText = lives;
      if (lives <= 0) {
        endGame(false);
        return;
      } else {
        resetBall();
      }
    }
  }

  ball.x += ball.dx;
  ball.y += ball.dy;

  requestAnimationFrame(draw);
}

function resetBall() {
  ball.x = canvas.width / 2;
  ball.y = canvas.height - 30;
  ball.dx = ballSpeed;
  ball.dy = -ballSpeed;
}

function startGame() {
  nickname = document.getElementById("nickname").value;
  if (!nickname) return alert("Insira o nickname!");

  score = 0;
  lives = 3;
  ballSpeed = 2;
  gameRunning = true;
  document.getElementById("score").innerText = score;
  document.getElementById("lives").innerText = lives;

  resetBall();
  createBricks();

  document.getElementById("entry").style.display = "none";
  document.getElementById("scoreboard").style.display = "none";
  document.getElementById("game-over").style.display = "none";
  document.getElementById("game").style.display = "block";

  const msg = document.getElementById("wasd-message");
  msg.style.display = "block";
  clearTimeout(showMessageTimeout);
  showMessageTimeout = setTimeout(() => {
    msg.style.display = "none";
  }, 2000);

  draw();
}

function endGame(won) {
  gameRunning = false;
  document.getElementById("game").style.display = "none";
  document.getElementById("game-over").style.display = "block";
  document.getElementById("game-over-message").innerText = won ? "Ganhou!" : "Perdeu!";
  document.getElementById("final-score").innerText = `Pontuação Final: ${score}`;

  const scores = JSON.parse(localStorage.getItem("scores") || "[]");
  scores.push({ name: nickname, score });
  scores.sort((a, b) => b.score - a.score);
  localStorage.setItem("scores", JSON.stringify(scores));
}

function goToEntry() {
  document.getElementById("entry").style.display = "block";
  document.getElementById("game").style.display = "none";
  document.getElementById("game-over").style.display = "none";
  document.getElementById("scoreboard").style.display = "none";
}

function showScoreboard() {
  const scores = JSON.parse(localStorage.getItem("scores") || "[]");
  const scoresDiv = document.getElementById("scores");
  scoresDiv.innerHTML = scores
    .map(s => `<div class='scoreboard-entry'>${s.name}: ${s.score}</div>`)
    .join("");
  document.getElementById("entry").style.display = "none";
  document.getElementById("scoreboard").style.display = "block";
}

window.onload = () => {
  document.getElementById("entry").style.display = "block";
};
