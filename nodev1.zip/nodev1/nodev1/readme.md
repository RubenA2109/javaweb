Como comecar o projeto em node:
node index.js

Instalar a extensao:
Thunder Client

Se der erro ao iniciar mudar a porta:
http://localhost:3000 mudar para 3001; 3002...

No relampago do lado esquerdo clico e no link substituio por:
http://localhost:3000/api/produtos/

Deve aparecer o sewguinte:
[
  {
    "id": 1,
    "nome": "dev",
    "preco": "5.00"
  }
]

Ao mudar e meter um produto que seja 2 ou mais por exemplo:
http://localhost:3000/api/produtos/2

Tem de aparecer vazio

Para adicionar produtos:
'Criar um New Request'

Por exemplo, no post escrevo isto e depois send:
{
  "nome": "ccc",
  "preco": "4"
}

Depois mdo para get e send

Para apagar mudo para 'DELETE' e se quiser apagar o produto 2 faco isto:
http://localhost:3000/api/produtos/2

Se quiser apagar o produto 3 faco isto:
http://localhost:3000/api/produtos/3