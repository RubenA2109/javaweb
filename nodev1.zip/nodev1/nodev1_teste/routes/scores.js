// routes/scores.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// GET todos os scores
router.get('/', (req, res) => {
  db.query('SELECT * FROM scores', (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});


// GET scores por ID
router.get('/:id', (req, res) => {
  db.query('SELECT * FROM scores WHERE id = ?', [req.params.id], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results[0]);
  });
});

// GET scores por game
router.get('/bygame/:game', (req, res) => {
  db.query('SELECT * FROM game WHERE game = ?', [req.params.game], (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
});

// POST inserir scores
router.post('/', (req, res) => {
  const {datascores, nickname, scores, game } = req.body;
  db.query('INSERT INTO scores (datascores, nickname, scores, game) VALUES (?, ?, ?, ?)', [datascores, nickname, scores, game], (err, result) => {
      if (err) return res.status(500).json(err);
      res.json({ id: result.insertId,});
      res.json(results);
  });
});

// PUT atualizar scores
router.put('/:id', (req, res) => {
  const {datascores, nickname, scores, game } = req.body;
  db.query('UPDATE scores SET datascores = ?, nickname = ?, scores = ?, game = ? WHERE id = ?', [datascores, nickname, scores, game, req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ id: req.params.id, datascores, nickname, scores, game });
  });
});

// DELETE scores por id
router.delete('/:id', (req, res) => {
  db.query('DELETE FROM scores WHERE id = ?', [req.params.id], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ status: 'Produto removido' });
  });
});

// DELETE scores por game
router.delete('/bygame/:game', (req, res) => {
  db.query('DELETE FROM scores WHERE game = ?', [req.params.game], (err) => {
    if (err) return res.status(500).json(err);
    res.json({ status: 'Produto removido' });
  });
});


module.exports = router;